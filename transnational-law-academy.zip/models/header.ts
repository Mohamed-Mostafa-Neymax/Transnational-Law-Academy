export const SLIDES = [
    {
        title: 'Transnational Law Academy',
        description: 'Shaping the global legal landscape through innovative education, research, and collaboration.'
    },
    {
        title: 'Transnational Law Academy',
        description: 'Transforming aspiring legal minds into leaders through rigorous education and real-world experience.'
    },
    {
        title: 'Transnational Law Academy',
        description: 'Unlock your potential with a curriculum that blends legal theory with practical insights.'
    }
];