export const LINKS = [
    { title: 'Home', path: '/' },
    { title: 'About Us', path: '/about-us' },
    { title: 'Our People', path: '/our-people' },
    { title: 'Law Courses', path: '/law-courses' },
    { title: 'News', path: '/news' },
    { title: 'Contact Us', path: '/contact-us' }
];