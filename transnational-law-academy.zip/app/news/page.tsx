const NewsPage: React.FC = () => {
    return (
        <section className="pt-5 lg:pt-14 2xl:pt-20">
            <section className="px-5 py-12 md:px-10 lg:py-20 2xl:px-52 2xl:py-32">
                <h1 className="text-center text-[#6F85F6] text-xl MontserratBold">This Page is under development</h1>
            </section>
        </section>
    );
}

export default NewsPage;